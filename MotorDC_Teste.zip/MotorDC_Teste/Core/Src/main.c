/*
 * main.c
 *
 *  Created on: Nov 13, 2022
 *      Author: Yuri e Luiz
 */

#include "main.h"
#include "MotorDC.h"

#define DC_MOTOR1    0


void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_ADC1_Init(void);

int main(void)
{
    uint16_t AD_RES = 0;


    DC_MOTOR_Init(DC_MOTOR1);
    DC_MOTOR_Start(DC_MOTOR1, DIR_CW, 100);

    while (1)
    {

    uint16_t motorL = 0;

	while(motorL<2000){
	motorL = motorL + 1;


	DC_MOTOR_Set_Speed(DC_MOTOR1, AD_RES>>2);
	HAL_Delay(1);

	}
	DC_MOTOR_Stop(DC_MOTOR1);
    }
}
