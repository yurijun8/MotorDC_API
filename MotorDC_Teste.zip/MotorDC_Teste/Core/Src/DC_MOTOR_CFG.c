#include "MotorDC.h"

const DC_MOTOR_CfgType DC_MOTOR_CfgParam[DC_MOTOR_UNITS] =
{
	// DC MOTOR 1 Configurations
    {
	    GPIOB,
		GPIOB,
		GPIO_PIN_12,
		GPIO_PIN_13,
		TIM5,
		TIM_CHANNEL_1,
		72
	}
};
